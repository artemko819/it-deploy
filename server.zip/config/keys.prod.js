module.exports = {
    jwt:process.env.JWT
}