module.exports.overview = function(req,res){
 res.status(200).json({
     "message":"123213"
 })
}

module.exports.analytics = function(req,res){

}