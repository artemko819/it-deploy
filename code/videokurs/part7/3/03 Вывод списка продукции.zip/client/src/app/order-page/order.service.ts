import {Injectable} from '@angular/core'

@Injectable()
export class OrderService {

  add(position) {}

  remove() {}

  clear() {}
}
