import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-positions',
  templateUrl: './order-positions.component.html',
  styleUrls: ['./order-positions.component.css']
})
export class OrderPositionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
