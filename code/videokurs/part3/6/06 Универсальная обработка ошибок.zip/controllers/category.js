module.exports.getAll = function(req, res) {
  res.json({message: 'Categories'})
}

module.exports.getById = function(req, res) {

}

module.exports.remove = function(req, res) {

}

module.exports.create = function(req, res) {

}

module.exports.update = function(req, res) {

}