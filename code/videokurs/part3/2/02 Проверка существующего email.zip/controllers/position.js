module.exports.getByCategoryId = function(req, res) {

}

module.exports.create = function(req, res) {

}

module.exports.remove = function(req, res) {

}

module.exports.update = function(req, res) {

}