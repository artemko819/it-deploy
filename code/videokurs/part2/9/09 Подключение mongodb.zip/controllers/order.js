module.exports.getAll = function(req, res) {

}

module.exports.create = function(req, res) {

}