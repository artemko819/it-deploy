module.exports = {
  mongoURI: 'mongodb://vladilen:123456@ds111410.mlab.com:11410/fullstack',
  jwt: 'dev-jwt'
}